from django.contrib import messages
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth import authenticate,login
from myapp.form import CustomUserForm
from .models import *

# Create your views here.

def home(request):
    return render(request, 'home/index.html')


def register(request):
    form=CustomUserForm()
    if request.method=='POST':
        form=CustomUserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Registration completed Successfully..!")
            return redirect('/login')    
    return render(request, 'home/register.html', {'form':form})

def login_page(request):
    if request.method=='POST':
        name=request.POST.get('username')
        pwd=request.POST.get('password')
        user=authenticate(request,username=name,password=pwd)
        if user is not None:
          login(request,user)
          messages.success(request,"Logged in Successfully")
          return redirect("/")
        else:
            messages.error(request,"Invalid User Name or Password") 
            return redirect("/login") 
            
    return render(request, 'home/login.html')